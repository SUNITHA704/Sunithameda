import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function FootwearCompanySite() {
  const [lang, setLang] = React.useState("en");

  const t = {
    en: {
      heroTitle: "Step into Comfort & Style",
      heroText: "EVA Footwear designed for suppliers and customers who value both affordability and quality.",
      explore: "Explore Collection",
      about: "About Us",
      aboutText: "We, SVP Footwear Manufactures, are actively looking for suppliers interested in joining the footwear industry. We offer zero-cost franchise opportunities and supply our EVA footwear at extremely low prices. Our mission is to deliver comfort and value without compromise for both suppliers and customers.",
      products: "Our Products",
      contact: "Contact Us",
      phone: "Phone",
      email: "Email",
      address: "Address",
      chat: "Chat on WhatsApp",
      franchiseForm: "Franchise Inquiry Form",
      name: "Your Name",
      mobile: "Mobile Number",
      message: "Your Message",
      submit: "Submit"
    },
    te: {
      heroTitle: "ఆరంభించండి కంఫర్ట్ మరియు స్టైల్ తో",
      heroText: "EVA ఫుట్‌వేర్ సరసమైన ధరకు సప్లయర్లు మరియు కస్టమర్ల కోసం రూపొందించబడింది.",
      explore: "కలెక్షన్ చూడండి",
      about: "మన గురించి",
      aboutText: "మేము SVP ఫుట్‌వేర్ మాన్యుఫ్యాక్చర్స్, ఫుట్‌వేర్ వ్యాపారంలో పాల్గొనదలచిన సప్లయర్లను వెతుకుతున్నాము. మేము ఎలాంటి ఫీజు లేకుండా ఫ్రాంచైజీ అవకాశం ఇస్తాము మరియు తక్కువ ధరకు EVA ఫుట్‌వేర్ అందిస్తున్నాము. మా లక్ష్యం మంచి నాణ్యతను అందుబాటులో అందించడం.",
      products: "మా ఉత్పత్తులు",
      contact: "మమ్మల్ని సంప్రదించండి",
      phone: "ఫోన్",
      email: "ఈమెయిల్",
      address: "చిరునామా",
      chat: "WhatsApp లో చాట్ చేయండి",
      franchiseForm: "ఫ్రాంచైజీ ప్రశ్నాపత్రం",
      name: "మీ పేరు",
      mobile: "ఫోన్ నంబర్",
      message: "మీ సందేశం",
      submit: "సబ్మిట్ చేయండి"
    }
  };

  const langData = t[lang];

  return (
    <div className="font-sans text-gray-800">
      {/* Navbar */}
      <header className="bg-gradient-to-r from-gray-900 to-black text-white p-4 shadow-xl sticky top-0 z-50">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <h1 className="text-3xl font-extrabold tracking-wide">SVP Footwear</h1>
          <nav className="space-x-6 text-lg">
            <a href="#about" className="hover:text-yellow-400 transition">{langData.about}</a>
            <a href="#products" className="hover:text-yellow-400 transition">{langData.products}</a>
            <a href="#contact" className="hover:text-yellow-400 transition">{langData.contact}</a>
            <select
              value={lang}
              onChange={(e) => setLang(e.target.value)}
              className="bg-black border border-gray-600 rounded px-2 py-1 text-sm"
            >
              <option value="en">EN</option>
              <option value="te">TE</option>
            </select>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-yellow-50 py-24 text-center">
        <h2 className="text-5xl font-bold text-gray-900 mb-6">{langData.heroTitle}</h2>
        <p className="text-xl text-gray-700 mb-8 max-w-2xl mx-auto">{langData.heroText}</p>
        <Button className="bg-yellow-500 hover:bg-yellow-600 text-black px-6 py-3 text-lg rounded-full">{langData.explore}</Button>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 bg-white max-w-6xl mx-auto px-6">
        <h3 className="text-4xl font-bold mb-6 text-center text-gray-800">{langData.about}</h3>
        <p className="text-lg leading-relaxed text-gray-700 text-center max-w-3xl mx-auto">{langData.aboutText}</p>
      </section>

      {/* Product Showcase */}
      <section id="products" className="bg-gray-50 py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <h3 className="text-4xl font-bold mb-12 text-center text-gray-800">{langData.products}</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map((item) => (
              <Card key={item} className="shadow-xl rounded-2xl border border-gray-200">
                <CardContent className="p-4">
                  <img
                    src={`https://via.placeholder.com/300x200?text=Footwear+${item}`}
                    alt={`Footwear ${item}`}
                    className="w-full h-48 object-cover rounded-xl mb-4"
                  />
                  <h4 className="text-xl font-semibold text-gray-800">Footwear {item}</h4>
                  <p className="text-sm text-gray-600">Durable, stylish, and comfortable EVA footwear perfect for everyday wear and business reselling.</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Franchise Form Section */}
      <section className="bg-white py-24 px-6 max-w-3xl mx-auto">
        <h3 className="text-4xl font-bold mb-8 text-center text-gray-800">{langData.franchiseForm}</h3>
        <form
          action="https://formsubmit.co/medadilip2017@gmail.com"
          method="POST"
          className="space-y-6"
        >
          <input type="hidden" name="_captcha" value="false" />
          <input
            type="text"
            name="name"
            placeholder={langData.name}
            required
            className="w-full px-4 py-3 border border-gray-300 rounded-lg"
          />
          <input
            type="tel"
            name="phone"
            placeholder={langData.mobile}
            required
            className="w-full px-4 py-3 border border-gray-300 rounded-lg"
          />
          <textarea
            name="message"
            placeholder={langData.message}
            required
            className="w-full px-4 py-3 border border-gray-300 rounded-lg h-32"
          ></textarea>
          <Button type="submit" className="bg-yellow-500 hover:bg-yellow-600 text-black text-lg px-6 py-3 rounded-full">
            {langData.submit}
          </Button>
        </form>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 bg-white max-w-4xl mx-auto px-6">
        <h3 className="text-4xl font-bold mb-8 text-center text-gray-800">{langData.contact}</h3>
        <div className="text-lg text-gray-700 space-y-4 text-center">
          <p><strong>{langData.phone}:</strong> 7207068211, 6305234260</p>
          <p><strong>{langData.email}:</strong> medadilip2017@gmail.com</p>
          <p><strong>{langData.address}:</strong> 12-34, Village Rajeevnagar, Mandal Devarupula, Dist. Jangoan, Telangana, India - 506303</p>
        </div>
        <div className="mt-6 text-center">
          <a
            href="https://wa.me/917207068211"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-green-500 hover:bg-green-600 text-white text-lg font-semibold px-6 py-3 rounded-full"
          >
            {langData.chat}
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white text-center py-6 text-sm">
        <p>&copy; 2025 SVP Footwear Manufactures. All rights reserved.</p>
        <p>Languages Supported: English, Telugu</p>
      </footer>
    </div>
  );
}
